# -*- coding: utf-8 -*-
__author__ = 'Andile Jaden Mbele'
__email__ = 'andilembele020@gmail.com'
__github__ = 'https://github.com/xeroxzen/genuine-fake'
__package__ = 'genuine-fake'
__version__ = '1.2.20'
