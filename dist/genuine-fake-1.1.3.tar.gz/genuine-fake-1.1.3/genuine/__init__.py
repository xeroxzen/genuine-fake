# -*- coding: utf-8 -*-

Author = 'Andile Jaden Mbele'
Email = 'andilembele020@gmail.com'
Github='www.github.com/xeroxzen/chameleon'

__author__ = Author
__email__ = Email
__github__ = Github